#!/usr/bin/env python3
import argparse, hashlib, json
from pathlib import Path

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

p = argparse.ArgumentParser()
p.add_argument('file')
p.add_argument('--chunk-mib', type=int, default=8)
p.add_argument('--out', default='transfer_parts')
args = p.parse_args()

src = Path(args.file)
out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
chunk_bytes = args.chunk_mib * 1024 * 1024
parts = []

with src.open('rb') as f:
    i = 1
    while True:
        data = f.read(chunk_bytes)
        if not data:
            break
        name = f'part{i:03d}.bin'
        path = out / name
        path.write_bytes(data)
        parts.append({'name': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        i += 1

manifest = {
    'archive_name': src.name,
    'archive_bytes': src.stat().st_size,
    'archive_sha256': sha256_file(src),
    'chunk_mib': args.chunk_mib,
    'parts': parts
}
(out / 'transfer_manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding='utf-8')
print(json.dumps(manifest, indent=2, ensure_ascii=False))
