#!/usr/bin/env python3
import argparse, hashlib
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('file')
p.add_argument('--bytes', type=int, required=True)
p.add_argument('--sha256', required=True)
args = p.parse_args()

path = Path(args.file)
actual_bytes = path.stat().st_size
h = hashlib.sha256()
with path.open('rb') as f:
    for chunk in iter(lambda: f.read(1024 * 1024), b''):
        h.update(chunk)
actual_sha = h.hexdigest()
print('bytes:', actual_bytes)
print('sha256:', actual_sha)
if actual_bytes != args.bytes:
    raise SystemExit(f'BYTE_MISMATCH expected={args.bytes} actual={actual_bytes}')
if actual_sha.lower() != args.sha256.lower():
    raise SystemExit(f'SHA256_MISMATCH expected={args.sha256} actual={actual_sha}')
print('VERIFIED')
