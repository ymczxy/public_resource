#!/usr/bin/env python3
import argparse, hashlib, json, shutil
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('manifest')
p.add_argument('--parts-dir', default='.')
p.add_argument('--out')
args = p.parse_args()

manifest = json.loads(Path(args.manifest).read_text(encoding='utf-8'))
parts_dir = Path(args.parts_dir)
out = Path(args.out or manifest['archive_name'])

for part in manifest['parts']:
    path = parts_dir / part['name']
    if path.stat().st_size != part['bytes']:
        raise SystemExit(f"SIZE_MISMATCH {part['name']}")
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    if h.hexdigest() != part['sha256']:
        raise SystemExit(f"SHA_MISMATCH {part['name']}")

with out.open('wb') as dst:
    for part in manifest['parts']:
        with (parts_dir / part['name']).open('rb') as src:
            shutil.copyfileobj(src, dst)

h = hashlib.sha256()
with out.open('rb') as f:
    for chunk in iter(lambda: f.read(1024 * 1024), b''):
        h.update(chunk)
if out.stat().st_size != manifest['archive_bytes']:
    raise SystemExit('ARCHIVE_SIZE_MISMATCH')
if h.hexdigest() != manifest['archive_sha256']:
    raise SystemExit('ARCHIVE_SHA256_MISMATCH')
print(f"MERGED_AND_VERIFIED {out} {out.stat().st_size} {h.hexdigest()}")
