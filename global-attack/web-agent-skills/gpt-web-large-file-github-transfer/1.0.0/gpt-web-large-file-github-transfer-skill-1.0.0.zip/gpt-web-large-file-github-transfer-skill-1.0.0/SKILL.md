---
name: gpt-web-large-file-github-transfer
version: 1.0.0
description: GPT 网页会话中，通过连接器 + GitHub Actions 可靠上传/下载大体积二进制文件并做完整性校验。
scope: GPT web sessions
---

# GPT Web Large File ↔ GitHub Transfer Skill

## 0. 目标

用于 **GPT 网页会话**处理 ZIP / GLB / BLEND / STEP / TAR 等大体积二进制资产：

- 上传：网页会话本地文件 → GitHub 新独立 Release Asset。
- 下载：GitHub Release Asset → 网页会话本地容器。
- 全程以 **精确字节数 + SHA-256** 为最终验收依据。
- 不重建资产、不重新压缩替代原包、不覆盖已有 Release/Asset。
- 只有回下载校验通过后，才允许报告“上传成功”或“下载成功”。

---

## 1. 网页会话中的关键事实

### 1.1 `/mnt/data/...` 本地路径不等于连接器文件引用
很多连接器写动作需要 connector file reference / file_uri。直接传本地路径可能报 `UNREGISTERED_FILE_REFERENCE`、413 或大小限制。遇到后不要原样重复提交。

### 1.2 GitHub 普通 `fetch` 是文本读取接口
它适合 Release 元数据、目录、文本、workflow run/job JSON；对 ZIP/GLB/BLEND 等二进制出现 UTF-8 解码错误，不代表 GitHub 不能传二进制。

### 1.3 `create_blob(base64)` 能写二进制，但不适合大包
可用于小型二进制探针。不要把 100+ MB 整包 Base64 后塞进一个调用：Base64 会膨胀约 33%，普通 Git blob/文件和工具 payload 都可能有限制。

### 1.4 GitHub Actions 是网页会话的大文件桥
Actions runner 可使用 `${{ github.token }}`，在 `permissions: contents: write` 下创建/上传 Release，可运行 `gh release upload/download`，也可用 `actions/upload-artifact` 暂存二进制。因此网页会话只需把原始字节可靠送到 runner。

---

# 2. 上传大文件到 GitHub Release

## 2.1 上传前强制基线
先记录：

```text
FILE_NAME
FILE_BYTES
FILE_SHA256
TARGET_REPO
NEW_TAG
RELEASE_NAME
```

推荐 tag：`<asset-name>-<sha256前8~12位>`。

必须先检查：
- tag 不存在；
- Release 不存在；
- 不使用 `--clobber`；
- 不覆盖旧资产；
- 用户已授权上传。

### 成功标准
必须全部满足：
1. runner 重组后 bytes == 原文件 bytes；
2. runner 重组后 SHA-256 == 原文件 SHA-256；
3. Release Asset 状态为 `uploaded`；
4. GitHub 返回资产大小正确；
5. `gh release download` 回下载后 bytes/SHA-256 一致；
6. 公共仓库建议再做一次无认证下载验证；
7. 清理临时传输资源。

## 2.2 推荐主路径：分片中转 → Actions → Release

### A. 分片
默认建议 **8 MiB/片**。使用本 Skill 的 `scripts/split_file.py`。生成：

```text
part001.bin
part002.bin
...
transfer_manifest.json
```

每片必须记录：
```json
{"name":"part001.bin","bytes":8388608,"sha256":"..."}
```

### B. 把分片放入网页会话可用的临时文件中转
优先使用当前可用的文件/云盘连接器。

以 Google Drive 为例：
1. `upload_file` 上传每片；
2. 对真实 Drive 文件调用：

```text
fetch(
  url=<Drive文件URL>,
  download_raw_file=True,
  include_base64=False
)
```

3. 从**实际返回值**读取新的 `file_uri` / `download_url`；
4. 不要把 Drive 网页查看地址当 raw 下载地址；
5. 不要自己拼 signed URL；
6. signed URL 有时效性，应该即取即用。

若 `upload_file` 报 `UNREGISTERED_FILE_REFERENCE`，说明本地路径尚未转换成连接器引用，应先通过网页会话的文件输出/重新登记机制生成 connector-visible file reference，不能无限重试原调用。

### C. 创建一次性 GitHub 临时分支和 workflow
推荐分支：`transfer/<transfer-id>`。Workflow：

```yaml
permissions:
  contents: write
```

只在该临时分支触发。不要修改 `main` 来做一次性传输。

### D. 传输清单
清单至少包含：

```json
{
  "archive_name":"foo.zip",
  "archive_bytes":123456789,
  "archive_sha256":"...",
  "complete":true,
  "parts":[
    {"name":"part001.bin","bytes":8388608,"sha256":"...","url":"https://...temporary-signed-url..."}
  ]
}
```

如果 signed URL 被写到公共临时分支，它等价于短期公开能力。**只用于已经授权公开发布的资产**；私密资产不要使用公共 signed URL + 公共仓库 manifest 方案。

### E. Actions 下载并逐片核验
runner 使用：

```bash
curl --fail --silent --show-error --location \
  --max-time 120 \
  "$PART_URL" \
  -o "$PART_FILE"
```

每片必须校验 bytes + SHA-256。失败片可重试，已成功片不要重复下载。

### F. 重组并核验整包
严格按编号顺序重组：

```bash
cat part001.bin part002.bin ... > "$ARCHIVE"
```

验证：

```bash
stat -c %s "$ARCHIVE"
sha256sum "$ARCHIVE"
```

ZIP 还应执行：

```bash
unzip -t "$ARCHIVE"
```

包内若有 manifest，再逐文件核验。

### G. 创建 Draft Release
再次确认 tag/release 不存在。先创建草稿，避免坏包直接公开：

```bash
gh release create "$TAG" \
  --repo "$REPO" \
  --title "$RELEASE_NAME" \
  --draft \
  --notes-file release_notes.md
```

### H. 上传原始资产

```bash
gh release upload "$TAG" "$ARCHIVE" --repo "$REPO"
```

默认**禁止** `--clobber`。

### I. 认证回下载并核验

```bash
mkdir verify
gh release download "$TAG" \
  --repo "$REPO" \
  --pattern "$ARCHIVE_NAME" \
  --dir verify
```

再次核对 bytes + SHA-256。

### J. 发布
回下载正确后再发布 draft。归档型 Release 建议 `make_latest=false`。

### K. 公共下载复验
公共仓库再执行一次：

```bash
curl -fL "$BROWSER_DOWNLOAD_URL" -o public-roundtrip.bin
```

核对 bytes + SHA-256。只有此时才可报告 `UPLOAD SUCCESS`。

---

# 3. 从 GitHub 下载大文件到 GPT 网页会话

## 3.1 先读取 Release 元数据
通过 GitHub 连接器确认：

```text
repository
tag
asset name
asset size
asset digest/SHA-256（若 GitHub 返回）
browser_download_url
```

### 容器可直连时
优先：

```bash
curl -fL "$ASSET_URL" -o "$LOCAL_FILE"
sha256sum "$LOCAL_FILE"
stat -c %s "$LOCAL_FILE"
```

用户本地 Codex / CLI：

```bash
gh release download "$TAG" --repo "$REPO" --pattern "$ASSET_NAME"
```

## 3.2 GPT 网页容器直连失败时：Actions Artifact Bridge
标准 fallback：

1. 建一次性下载分支 + workflow；
2. runner 执行 `gh release download`；
3. runner 内核验 bytes / SHA-256；
4. `actions/upload-artifact@v4` 暂存；
5. 网页会话通过 GitHub 连接器：
   - 找 workflow run id；
   - `fetch_workflow_run_artifacts(run_id)`；
   - 获取**真实 artifact_id**；
   - `download_workflow_artifact(artifact_id)`；
6. 确认文件真实落到网页会话可用路径；
7. 本地再次核对 bytes + SHA-256。

参考：`examples/download_release_to_actions_artifact.yml`。

### Actions Artifact 不是长期源
长期恢复依据应保存：

```text
repo
release tag
asset name
asset bytes
asset SHA-256
```

不要把临时 artifact signed URL 当唯一恢复入口。

---

# 4. 什么时候用哪条路线

| 情况 | 推荐 |
|---|---|
| 小二进制探针 | `create_blob(base64)` 可用 |
| 10~100+ MB 上传 | 分片中转 + Actions + Release |
| >100 MiB 上传 | 必须优先分片，不要整包经过单个 connector bridge |
| 公共 Release 下载且容器可 curl | 直接 curl |
| 用户本地 Codex | `gh release download` |
| GPT 网页容器不能直连 Release | Actions Artifact Bridge |
| 私密资产 | 不用公共 signed URL / 公共临时分支方案 |

---

# 5. 失败定位规则

以下都不能直接推出“GitHub 无法传二进制”：
- `GitHub.fetch` UTF-8 解码失败；
- 某个 bridge 报 100 MiB 限制；
- Drive 网页 URL 下载得到登录 HTML；
- signed URL 过期；
- 本地路径不能直接传 connector；
- `create_blob` 小样成功但整包尚未执行。

按层定位：

```text
local file
→ connector registration
→ staging upload
→ signed URL
→ runner download
→ part verify
→ merge verify
→ release create
→ release upload
→ roundtrip download
```

失败报告必须明确卡在哪一层。

---

# 6. 安全规则

1. 不把 PAT、Cookie、密码写进 workflow / commit / log。
2. Actions 内优先 `${{ github.token }}`。
3. 不把 GitHub token 发给外部下载域名。
4. signed URL 是短期 capability，只用于明确授权可发布内容。
5. 私密数据禁止走公共 signed URL / 公共仓库 manifest。
6. 不覆盖旧资产，不默认 `--clobber`。
7. 不强推 `main`。
8. 临时 workflow/branch/staging 文件成功后清理。
9. 删除临时分支不等于抹除 Git 历史，敏感凭证绝不能提交进去。
10. 成功必须由实际字节校验确认，不能只凭 HTTP 200 或 UI 状态。

---

# 7. GPT 网页会话执行清单

## 上传
```text
[ ] 原包存在
[ ] 记录 bytes
[ ] 记录 SHA-256
[ ] tag 不存在
[ ] release 不存在
[ ] 用户授权上传
[ ] 分片
[ ] 每片 bytes / SHA-256
[ ] 分片暂存
[ ] 获取真实 raw / signed URL
[ ] 建临时 branch
[ ] 建临时 Actions workflow
[ ] runner 收到全部分片
[ ] 每片校验通过
[ ] 重组 bytes / SHA-256 通过
[ ] ZIP / manifest（如有）通过
[ ] 创建 draft release
[ ] gh release upload
[ ] gh release download 回下载
[ ] 回下载 bytes / SHA-256 通过
[ ] 发布 release
[ ] 公共下载复验（公共仓库）
[ ] 回读 Release metadata
[ ] 清理临时 branch / workflow / staging files
```

## 下载
```text
[ ] 找到正确 repo / tag / asset
[ ] 读取 asset bytes / digest
[ ] 优先 direct curl / gh
[ ] direct 失败则 Actions Artifact Bridge
[ ] Actions 下载 release asset
[ ] Actions 内校验
[ ] upload-artifact
[ ] 获取真实 artifact_id
[ ] download_workflow_artifact
[ ] 确认本地真实文件存在
[ ] bytes / SHA-256 再校验
[ ] 清理临时 workflow / branch（需要时）
```

---

# 8. 回复用户时的固定要求

成功至少提供：

```text
repository
release page
asset direct download URL
exact bytes
SHA-256
upload/download success = true
verification method
```

失败至少提供：

```text
upload/download success = false
failed stage
exact error
what was / was not modified
```

严禁：
- 没有真实 Release 就编造链接；
- 没有回下载校验就说成功；
- 小样成功就说整包成功；
- URL 返回登录 HTML 却当原文件；
- 因一个文本工具不支持二进制就声称所有连接器都不支持。

---

# 9. 已验证的主模式

```text
网页会话现有大文件
→ 分片
→ connector staging
→ fresh signed URL
→ GitHub Actions curl 接收
→ 逐片 SHA-256
→ 重组整包
→ 整包 SHA-256
→ draft Release
→ gh release upload
→ gh release download
→ public download
→ SHA-256 一致
→ 清理临时资源
```

这是本 Skill 的主路径。
