# GPT Web Large File ↔ GitHub Transfer Skill

专用于 GPT / ChatGPT 网页会话中的大文件 GitHub 上传和下载。

## 使用方法

把整个 ZIP 上传到新的 GPT 网页会话，然后说：

> 读取这个 Skill，并按 SKILL.md 执行。我要把当前会话生成的大文件上传到 GitHub Release。

或：

> 读取这个 Skill，并按 SKILL.md 执行。我要从 GitHub Release 下载大文件到当前网页会话容器。

## 核心原则

- 上传：分片 → 临时中转 → GitHub Actions → Release Asset。
- 下载：优先 curl/gh；网页容器受限时走 Actions Artifact Bridge。
- 所有成功都必须经过精确字节数 + SHA-256 验证。
- 禁止覆盖旧 Release/Asset，禁止凭 API 200 或 UI 状态误报成功。

版本：1.0.0
